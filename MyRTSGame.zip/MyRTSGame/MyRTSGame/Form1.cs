﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyRTSGame
{
    public partial class Form1 : Form
    {
        GameEngine engine = new GameEngine();

        public Form1()
            {
                InitializeComponent();
            }

            private void frmSimulation_Load(object sender, EventArgs e)
            {
                //timer1 properties were set in design view of the form. kick on the drag and drop object
                System.Windows.Forms.DialogResult result = MessageBox.Show("Would you like to load an old game?", "Load Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                    engine.map.loadMap();
                else
                    engine.map.populate();
            }


            private void lblMap_Click(object sender, EventArgs e)
            {
                int mouseX = MousePosition.X;
                int mouseY = MousePosition.Y;

                int formX = this.Location.X;
                int formY = this.Location.Y;

                int X = (mouseX - formX - 39 - 6) / 15;
                int Y = (mouseY - formY - 70 - 1) / 15;

                txtDisplay.Text = "";
                foreach (Unit u in engine.map.UnitsOnMap)
                {
                    if (u.X == X && u.Y == Y)
                    {
                        txtDisplay.Text += u.ToString();
                    }
                }
            }

            private void btnExit_Click_1(object sender, EventArgs e)
            {
                System.Windows.Forms.DialogResult result = MessageBox.Show("Would you like to save the game?", "Exit Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    engine.map.saveMap();
                }
                Application.Exit();
            }

            private void btnStart_Click_1(object sender, EventArgs e)
            {
                btnPause.Enabled = true;
                btnStart.Enabled = false;
                lblTime.Enabled = true;
                lblTime.Start();
            }

            private void btnPause_Click_1(object sender, EventArgs e)
            {
                btnPause.Enabled = true;
                btnStart.Enabled = false;
                lblTime.Stop();
            }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            lblTime.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            //show grid
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }
        }
    }
}

