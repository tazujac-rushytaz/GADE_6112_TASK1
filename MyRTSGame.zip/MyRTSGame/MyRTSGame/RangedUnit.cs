﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MyRTSGame
{
    class RangedUnit : Unit
    {

        private const int DAMAGE = 1;

        // constructor
        public RangedUnit(int x, int y, int health, int speed, bool attack, int attackRange, string faction, string symbol, string name)
            : base(x, y, health, speed, attack, attackRange, faction, symbol, name)
        {
        }

        // other overriden methods
        public override void move(int x, int y)
        {
            if (x >= 0 && x < 20)
                X = x;
            if (y >= 0 && y < 20)
                Y = y;
        }

        public override void combat(Unit enemy)
        {
            if (this.isWithinAttackRange(enemy))
            {
                enemy.Health -= DAMAGE;
            }
        }

        public override Unit nearestUnit(List<Unit> list)
        {
            Unit closest = null;
            int attackRangeX, attackRangeY;
            int shortestRange = 1000;

            foreach (Unit u in list)
            {
                attackRangeX = Math.Abs(this.x - u.X);
                attackRangeY = Math.Abs(this.y - u.Y);

                if (attackRangeX < shortestRange)
                {
                    shortestRange = attackRangeX;
                    closest = u;
                }
                if (attackRangeY < shortestRange)
                    shortestRange = attackRangeY;
                closest = u;
            }
            return closest;
        }

        public override bool isWithinAttackRange(Unit enemy)
        {
            if ((Math.Abs(this.X - enemy.X) <= this.attackRange) || (Math.Abs(this.X - enemy.X) <= this.AttackRange))
                return true;
            else
                return false;
        }

        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "X :" + X + Environment.NewLine
                + "y :" + Y + Environment.NewLine
                + "Health :" + Health + Environment.NewLine
                + "Speed :" + Speed + Environment.NewLine
                + "Attack :" + (Attack ? "Yes" : "No") + Environment.NewLine
                + "Attack Range :" + AttackRange + Environment.NewLine
                + "Faction/Team :" + Faction + Environment.NewLine
                + "Symbol :" + Symbol + Environment.NewLine
                + "Name : " + Name + Environment.NewLine;
            return output;

        }
        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {

                outFile = new FileStream(@"Files\RangedUnit.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(speed);
                writer.WriteLine(attack);
                writer.WriteLine(AttackRange);
                writer.WriteLine(faction);
                writer.WriteLine(symbol);
                writer.WriteLine(Name);
                writer.Close();
                outFile.Close();
            }
            catch (System.IO.IOException fe)
            {
                Console.WriteLine("IOExeption: " + fe.Message);
            }
            finally
            {
                if (outFile != null)
                    outFile.Close();
                if (writer != null)
                    writer.Close();
            }
        }
    }
 }
